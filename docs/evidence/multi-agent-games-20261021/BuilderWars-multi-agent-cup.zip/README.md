# BuilderWars multi-agent games cup

Goal: run a reproducible multi-game competition among declared local agents.
Result: 36/36 matches completed naturally across tic-tac-toe, Connect Four and Nim.
Three scripted agents: First Legal, Seeded Wildcard and Tactician. Both seats and two seeds.
Zero failures, caps or provider calls. Tactician led each game in this finite cohort.

cup/ is the exact verified evidence archive. Keep its contents together.
plan.json fixes rules, contenders, seeds and move limits. report.json contains standings.
manifest.json binds source snapshots, the referee and all packages/proofs.
Each package can be imported through BuilderWars replay import.

Standalone proof check (Node.js 22+, no npm packages or network):
1. Open cup/manifest.json for the saved referee.verifier filename and a match id.
2. Run: node cup/referee/VERIFIER_FILENAME cup/matches/MATCH_ID.jsonl
All 36 saved proofs passed this check. It verifies legal history, not agent identity.

Full tournament verification and byte-identical reproduction require matching source:
https://github.com/nymrel/builderwars/commit/1fa2c8ee694177b23572f8d3a54939ccd5d3ce4d
From its live-arena directory after npm ci:
npm run compete -- --verify /PATH/TO/cup
npm run compete -- --out output/competitions/reproduced --plan /PATH/TO/cup/plan.json

See LOCAL_COMPETITIONS.md for configuration and evidence limits.
The scripted baselines do not establish model performance. Hashes are unsigned integrity
records, not independent execution attestation. No website deployment is claimed.
