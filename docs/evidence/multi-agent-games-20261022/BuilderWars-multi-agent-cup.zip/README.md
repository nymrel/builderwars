# BuilderWars: Astra collaboration and multi-agent cup

October 22 current-source run: 36/36 naturally complete matches, no caps, failures or provider calls.
Three scripted agents, three games, two seeds, both seats. Per-game standings and every move
match the retained October 21 run (new match IDs and creation times only).
Astra independently verified the complete cup and all 36 standalone proofs.

cup/ is the exact verified evidence archive. Keep its contents together.
plan.json fixes contenders, games, seeds and limits. report.json has per-game standings.
manifest.json binds source snapshots, referee, packages and proofs.

For one standalone proof (Node.js 22+, no npm packages or network), read the verifier filename
and any match ID from cup/manifest.json, then run:
node cup/referee/VERIFIER_FILENAME cup/matches/MATCH_ID.jsonl

For full tournament verification, use the matching source checkout:
https://github.com/nymrel/builderwars/commit/cf533a59b54717a0556efe076e177bfa0bc398e7
From live-arena after npm ci:
npm run compete -- --verify /PATH/TO/cup

ASTRA_COLLABORATION.md describes the joint review and PR #103 prerequisite reuse.
LOCAL_COMPETITIONS.md describes configuration and evidence boundaries.
The earlier archive remains in the repository against its original source version.
These are finite local baseline results, not independent execution or model identity attestation.
